export type Props = {
  setStep: (state: number) => void;
  ethPay: number;
  plan: any;
};
