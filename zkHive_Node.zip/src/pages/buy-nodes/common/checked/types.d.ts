export type Props = {
  setStep: (state: number) => void
  step: number
}
