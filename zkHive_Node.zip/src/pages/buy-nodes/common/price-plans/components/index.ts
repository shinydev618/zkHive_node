export { PriceCard } from './pric-card'
