import { HomeUI } from "./style";

export const HomePage = () => {
  return (
    <HomeUI>
      <h1>HOME</h1>
    </HomeUI>
  );
};

export default HomePage;
