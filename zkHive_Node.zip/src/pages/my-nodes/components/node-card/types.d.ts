export type Props = {
  title: string;
};
