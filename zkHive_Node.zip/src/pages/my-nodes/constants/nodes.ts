export const NODES = [
  {
    nodeName: "Basic",
  },
  {
    nodeName: "Advanced",
  },
  {
    nodeName: "Full",
  },
  {
    nodeName: "Full",
  },
  {
    nodeName: "Basic",
  },
];
