import { Footer as FooterComponent } from './style'
export const Footer = () => (
  <FooterComponent>
    <p>© 2024 zkHive Node. All Rights Reserved</p>
  </FooterComponent>
)
